/* Forms - FormLayout.js */

export const FormLayout = {
    init(container = document) {
      // Enhance inline form labels accessibility
      const inlineGroups = container.querySelectorAll(".form-inline .form-group input, .form-inline .form-group select");
      
      inlineGroups.forEach(input => {
        const label = input.parentElement.querySelector("label");
        if (label && !label.classList.contains("sr-only")) {
          label.setAttribute("style", "min-width: 80px;"); // keep labels aligned
        }
      });
    }
  };
  
  
  