/* Forms - Validation.js */

export const Validation = {
    init(formSelector = "form") {
      const forms = document.querySelectorAll(formSelector);
  
      forms.forEach(form => {
        form.addEventListener("submit", e => {
          if (!form.checkValidity()) {
            e.preventDefault();
            e.stopPropagation();
          }
  
          form.classList.add("was-validated");
        });
      });
    },
  
    setValid(input, message = "") {
      input.classList.remove("is-invalid", "is-warning");
      input.classList.add("is-valid");
  
      let feedback = input.nextElementSibling;
      if (feedback && feedback.classList.contains("valid-feedback")) {
        feedback.textContent = message;
      }
    },
  
    setInvalid(input, message = "") {
      input.classList.remove("is-valid", "is-warning");
      input.classList.add("is-invalid");
  
      let feedback = input.nextElementSibling;
      if (feedback && feedback.classList.contains("invalid-feedback")) {
        feedback.textContent = message;
      }
    },
  
    setWarning(input, message = "") {
      input.classList.remove("is-valid", "is-invalid");
      input.classList.add("is-warning");
  
      let feedback = input.nextElementSibling;
      if (feedback && feedback.classList.contains("warning-feedback")) {
        feedback.textContent = message;
      }
    }
  };
  
  
  
  
  