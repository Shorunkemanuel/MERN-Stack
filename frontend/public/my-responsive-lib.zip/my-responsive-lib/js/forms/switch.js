/* Forms - Switch.js */

export const Switch = {
    isOn(toggle) {
      if (!(toggle instanceof HTMLInputElement)) return false;
      return toggle.checked;
    },
  
    setOn(toggle, state = true) {
      if (!(toggle instanceof HTMLInputElement)) return;
      toggle.checked = state;
      toggle.dispatchEvent(new Event("change"));
    },
  
    toggle(toggle) {
      if (!(toggle instanceof HTMLInputElement)) return;
      this.setOn(toggle, !this.isOn(toggle));
    },
  
    onChange(toggle, callback) {
      if (!(toggle instanceof HTMLInputElement)) return;
      toggle.addEventListener("change", e => {
        callback(e.target.checked, e);
      });
    },
  
    disable(toggle, disabled = true) {
      if (!(toggle instanceof HTMLInputElement)) return;
      toggle.disabled = disabled;
    },
  
    enable(toggle) {
      this.disable(toggle, false);
    }
  };
  
  
  