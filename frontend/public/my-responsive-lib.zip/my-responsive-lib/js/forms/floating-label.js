/* Forms - FloatingLabel.js */

export const FloatingLabel = {
    init(container = document) {
      const elements = container.querySelectorAll(".form-floating input, .form-floating textarea, .form-floating select");
      
      elements.forEach(el => {
        this.updateLabel(el);
        el.addEventListener("input", () => this.updateLabel(el));
        el.addEventListener("focus", () => this.updateLabel(el));
        el.addEventListener("blur", () => this.updateLabel(el));
      });
    },
  
    updateLabel(el) {
      const label = el.parentElement.querySelector("label");
      if (!label) return;
  
      if (el.value.trim() !== "" || el === document.activeElement) {
        label.classList.add("active");
      } else {
        label.classList.remove("active");
      }
    }
  };
  
  