/* Forms - Range.js */

export const Range = {
    getValue(slider) {
      if (!(slider instanceof HTMLInputElement)) return null;
      return parseFloat(slider.value);
    },
  
    setValue(slider, value) {
      if (!(slider instanceof HTMLInputElement)) return;
      slider.value = value;
      slider.dispatchEvent(new Event("input"));
    },
  
    onInput(slider, callback) {
      if (!(slider instanceof HTMLInputElement)) return;
      slider.addEventListener("input", e => {
        callback(parseFloat(e.target.value), e);
      });
    },
  
    onChange(slider, callback) {
      if (!(slider instanceof HTMLInputElement)) return;
      slider.addEventListener("change", e => {
        callback(parseFloat(e.target.value), e);
      });
    },
  
    disable(slider, disabled = true) {
      if (!(slider instanceof HTMLInputElement)) return;
      slider.disabled = disabled;
    },
  
    enable(slider) {
      this.disable(slider, false);
    }
  };
  
  
  
  