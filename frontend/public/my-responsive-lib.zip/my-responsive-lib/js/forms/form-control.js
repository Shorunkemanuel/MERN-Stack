/* Forms - FormControl.js */
/* Utilities for managing input states and interactions */

export const FormControl = {
    setValid(input, valid = true) {
      if (!(input instanceof HTMLElement)) return;
      input.classList.remove("is-valid", "is-invalid");
      input.classList.add(valid ? "is-valid" : "is-invalid");
    },
  
    clearState(input) {
      if (!(input instanceof HTMLElement)) return;
      input.classList.remove("is-valid", "is-invalid");
    },
  
    bindValidation(input, validatorFn) {
      if (!(input instanceof HTMLElement)) return;
      input.addEventListener("input", () => {
        const isValid = validatorFn(input.value);
        this.setValid(input, isValid);
      });
    }
  };
  
  
  
  