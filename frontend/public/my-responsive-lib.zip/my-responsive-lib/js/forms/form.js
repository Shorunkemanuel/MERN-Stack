/* =========================================
   form.js - Master script for forms
   Imports and initializes all form-related scripts
   ========================================= */

import './form-control.js';
import './select.js';
import './check-radio.js';
import './range.js';
import './switches.js';
import './floating-labels.js';
import './form-layout.js';
import './input-group.js';
import './validation.js';

/**
 * Initialize all form components
 */
export function initForms() {
  console.log("✅ Forms initialized");

  // Example auto-init if needed
  document.querySelectorAll("form[data-validate]").forEach(form => {
    form.addEventListener("submit", (e) => {
      // Hook validation.js
      if (!form.checkValidity()) {
        e.preventDefault();
        e.stopPropagation();
      }
      form.classList.add("was-validated");
    });
  });
}

// Auto-run if DOM ready
if (document.readyState !== "loading") {
  initForms();
} else {
  document.addEventListener("DOMContentLoaded", initForms);
}