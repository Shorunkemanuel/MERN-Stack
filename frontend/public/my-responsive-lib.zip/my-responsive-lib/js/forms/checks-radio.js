/* Forms - Checks & Radios.js */

export const ChecksRadios = {
    isChecked(input) {
      if (!(input instanceof HTMLInputElement)) return false;
      return input.checked;
    },
  
    setChecked(input, state = true) {
      if (!(input instanceof HTMLInputElement)) return;
      input.checked = state;
      input.dispatchEvent(new Event("change"));
    },
  
    toggle(input) {
      if (!(input instanceof HTMLInputElement)) return;
      this.setChecked(input, !input.checked);
    },
  
    disable(input, disabled = true) {
      if (!(input instanceof HTMLInputElement)) return;
      input.disabled = disabled;
    },
  
    enable(input) {
      this.disable(input, false);
    },
  
    onChange(input, callback) {
      if (!(input instanceof HTMLInputElement)) return;
      input.addEventListener("change", e => callback(e.target.checked, e));
    }
  };
  
  
  
  
  