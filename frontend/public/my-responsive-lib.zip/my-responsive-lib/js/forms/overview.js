/* Forms - Overview.js */
/* Basic helpers for form handling */

export const FormUtils = {
    serialize(form) {
      if (!(form instanceof HTMLFormElement)) {
        throw new Error("serialize() requires a form element");
      }
      const data = new FormData(form);
      return Object.fromEntries(data.entries());
    },
  
    reset(form) {
      if (form instanceof HTMLFormElement) {
        form.reset();
      }
    },
  
    isValid(form) {
      if (!(form instanceof HTMLFormElement)) return false;
      return form.checkValidity();
    },
  
    onSubmit(form, callback) {
      if (!(form instanceof HTMLFormElement)) return;
      form.addEventListener("submit", e => {
        e.preventDefault();
        if (form.checkValidity()) {
          callback(this.serialize(form), e);
        }
      });
    }
  };
  
  
  
  