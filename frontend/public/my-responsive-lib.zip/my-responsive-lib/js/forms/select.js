/* Forms - Select.js */
/* Utility functions for select elements */

export const Select = {
    getValue(select) {
      if (!(select instanceof HTMLSelectElement)) return null;
      return select.value;
    },
  
    setValue(select, value) {
      if (!(select instanceof HTMLSelectElement)) return;
      select.value = value;
      select.dispatchEvent(new Event("change"));
    },
  
    disable(select, disabled = true) {
      if (!(select instanceof HTMLSelectElement)) return;
      select.disabled = disabled;
    },
  
    enable(select) {
      this.disable(select, false);
    },
  
    onChange(select, callback) {
      if (!(select instanceof HTMLSelectElement)) return;
      select.addEventListener("change", e => callback(e.target.value, e));
    }
  };
  
  
  
  
  