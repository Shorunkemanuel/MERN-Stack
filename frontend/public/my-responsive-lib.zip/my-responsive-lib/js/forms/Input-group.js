/* Forms - InputGroup.js */

export const InputGroup = {
    init(container = document) {
      // Auto-detect if input group has icons or buttons and add class
      container.querySelectorAll(".input-group").forEach(group => {
        const hasButton = group.querySelector(".btn");
        const hasText = group.querySelector(".input-group-text");
        
        if (hasButton) {
          group.classList.add("has-btn");
        }
        if (hasText) {
          group.classList.add("has-text");
        }
      });
    }
  };
  
  
  