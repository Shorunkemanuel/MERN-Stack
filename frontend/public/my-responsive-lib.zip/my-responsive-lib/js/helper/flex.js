// Flex Helpers
export function toggleFlex(el, inline = false) {
  if (!el) return;
  el.classList.toggle(inline ? "d-inline-flex" : "d-flex");
}