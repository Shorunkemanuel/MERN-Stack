// Spacing Helpers
export function setMargin(el, value) {
  if (el) el.style.margin = value;
}
export function setPadding(el, value) {
  if (el) el.style.padding = value;
}