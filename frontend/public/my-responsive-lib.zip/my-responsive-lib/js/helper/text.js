// Text Helpers
export function truncateText(el, limit = 100) {
  if (!el) return;
  if (el.textContent.length > limit) {
    el.textContent = el.textContent.slice(0, limit) + '...';
  }
}

export function capitalizeText(el) {
  if (!el) return;
  el.textContent = el.textContent.replace(/\b\w/g, char => char.toUpperCase());
}