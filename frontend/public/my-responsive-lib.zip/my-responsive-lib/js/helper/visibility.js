// Visibility Helpers
export function show(el) {
  if (el) el.style.display = "";
}
export function hide(el) {
  if (el) el.style.display = "none";
}
export function toggle(el) {
  if (el) el.style.display = (el.style.display === "none" ? "" : "none");
}