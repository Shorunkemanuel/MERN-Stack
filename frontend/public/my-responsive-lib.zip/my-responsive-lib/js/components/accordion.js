/* Accordion.js */

import { on } from "../core/events.js";

export function initAccordion() {
  const accordions = document.querySelectorAll(".accordion");

  accordions.forEach((accordion) => {
    const headers = accordion.querySelectorAll(".accordion-header");

    headers.forEach((header) => {
      on(header, "click", () => {
        const body = header.nextElementSibling;

        // Close all items in the same accordion
        accordion.querySelectorAll(".accordion-body").forEach((panel) => {
          if (panel !== body) {
            panel.classList.remove("show");
          }
        });

        // Toggle current
        body.classList.toggle("show");
      });
    });
  });
}

