/* Carousel.css */

.carousel {
    position: relative;
    width: 100%;
    overflow: hidden;
  }
  
  .carousel-inner {
    display: flex;
    transition: transform var(--duration-medium) ease-in-out;
    will-change: transform;
  }
  
  .carousel-item {
    min-width: 100%;
    flex-shrink: 0;
    display: none;
    align-items: center;
    justify-content: center;
  }
  
  .carousel-item.active {
    display: flex;
  }
  
  /* Images inside carousel */
  .carousel img {
    width: 100%;
    height: auto;
    display: block;
    border-radius: var(--radius-md);
  }
  
  /* Controls */
  .carousel-control-prev,
  .carousel-control-next {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: rgba(0, 0, 0, 0.4);
    color: var(--color-white);
    border: none;
    padding: var(--space-sm) var(--space-md);
    cursor: pointer;
    border-radius: var(--radius-pill);
    z-index: var(--z-tooltip);
    font-size: 1.5rem;
  }
  
  .carousel-control-prev {
    left: var(--space-sm);
  }
  
  .carousel-control-next {
    right: var(--space-sm);
  }
  
  /* Indicators */
  .carousel-indicators {
    position: absolute;
    bottom: var(--space-md);
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    gap: var(--space-sm);
  }
  
  .carousel-indicators button {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    border: none;
    background-color: var(--color-gray-500);
    cursor: pointer;
  }
  
  .carousel-indicators .active {
    background-color: var(--color-primary);
  }
  
  
  