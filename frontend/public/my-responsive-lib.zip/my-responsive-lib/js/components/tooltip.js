/* Tooltips.js */

export class Tooltip {
    constructor(target, text, placement = "top") {
      this.target = target;
      this.text = text;
      this.placement = placement;
      this.tooltip = null;
  
      this.init();
    }
  
    init() {
      this.target.addEventListener("mouseenter", () => this.show());
      this.target.addEventListener("mouseleave", () => this.hide());
      this.target.addEventListener("focus", () => this.show());
      this.target.addEventListener("blur", () => this.hide());
    }
  
    create() {
      const tooltip = document.createElement("div");
      tooltip.className = "tooltip";
      tooltip.textContent = this.text;
      tooltip.setAttribute("data-placement", this.placement);
      document.body.appendChild(tooltip);
      this.tooltip = tooltip;
    }
  
    setPosition() {
      if (!this.tooltip) return;
  
      const rect = this.target.getBoundingClientRect();
      const tooltipRect = this.tooltip.getBoundingClientRect();
  
      let top, left;
  
      switch (this.placement) {
        case "top":
          top = rect.top - tooltipRect.height - 8;
          left = rect.left + rect.width / 2 - tooltipRect.width / 2;
          break;
        case "bottom":
          top = rect.bottom + 8;
          left = rect.left + rect.width / 2 - tooltipRect.width / 2;
          break;
        case "left":
          top = rect.top + rect.height / 2 - tooltipRect.height / 2;
          left = rect.left - tooltipRect.width - 8;
          break;
        case "right":
          top = rect.top + rect.height / 2 - tooltipRect.height / 2;
          left = rect.right + 8;
          break;
      }
  
      this.tooltip.style.top = `${top + window.scrollY}px`;
      this.tooltip.style.left = `${left + window.scrollX}px`;
    }
  
    show() {
      if (!this.tooltip) {
        this.create();
      }
      this.setPosition();
      requestAnimationFrame(() => {
        this.tooltip.classList.add("show");
      });
    }
  
    hide() {
      if (this.tooltip) {
        this.tooltip.classList.remove("show");
        setTimeout(() => {
          this.tooltip?.remove();
          this.tooltip = null;
        }, 300);
      }
    }
  }
  
  
  
  
  