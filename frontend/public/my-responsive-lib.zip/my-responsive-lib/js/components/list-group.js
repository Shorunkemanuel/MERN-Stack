/* ListGroup.js */

export class ListGroup {
    constructor(selector) {
      this.groups = document.querySelectorAll(selector);
  
      this.groups.forEach((group) => {
        group.addEventListener("click", (e) => {
          const item = e.target.closest(".list-group-item");
          if (!item) return;
  
          // Remove active class from siblings
          group.querySelectorAll(".list-group-item").forEach((i) => {
            i.classList.remove("active");
          });
  
          // Add active to clicked item
          item.classList.add("active");
        });
      });
    }
  }
  
  
  