/* Popovers.js */

export class Popover {
    constructor(triggerSelector, options = {}) {
      this.triggers = document.querySelectorAll(triggerSelector);
      this.options = Object.assign(
        {
          placement: "top",
          title: "",
          content: "",
          trigger: "click", // or hover, focus
        },
        options
      );
  
      this.popover = null;
      this.init();
    }
  
    init() {
      this.triggers.forEach(trigger => {
        if (this.options.trigger === "click") {
          trigger.addEventListener("click", e => this.toggle(e, trigger));
        } else if (this.options.trigger === "hover") {
          trigger.addEventListener("mouseenter", e => this.show(e, trigger));
          trigger.addEventListener("mouseleave", () => this.hide());
        } else if (this.options.trigger === "focus") {
          trigger.addEventListener("focus", e => this.show(e, trigger));
          trigger.addEventListener("blur", () => this.hide());
        }
      });
    }
  
    createPopover(trigger) {
      if (this.popover) this.popover.remove();
  
      const pop = document.createElement("div");
      pop.classList.add("popover");
      pop.dataset.placement = this.options.placement;
  
      if (this.options.title) {
        const header = document.createElement("div");
        header.classList.add("popover-header");
        header.textContent = this.options.title;
        pop.appendChild(header);
      }
  
      const body = document.createElement("div");
      body.classList.add("popover-body");
      body.innerHTML = this.options.content;
      pop.appendChild(body);
  
      document.body.appendChild(pop);
      this.popover = pop;
  
      this.setPosition(trigger);
    }
  
    setPosition(trigger) {
      const rect = trigger.getBoundingClientRect();
      const popRect = this.popover.getBoundingClientRect();
  
      let top, left;
      switch (this.options.placement) {
        case "top":
          top = rect.top - popRect.height - 8;
          left = rect.left + rect.width / 2 - popRect.width / 2;
          break;
        case "bottom":
          top = rect.bottom + 8;
          left = rect.left + rect.width / 2 - popRect.width / 2;
          break;
        case "left":
          top = rect.top + rect.height / 2 - popRect.height / 2;
          left = rect.left - popRect.width - 8;
          break;
        case "right":
          top = rect.top + rect.height / 2 - popRect.height / 2;
          left = rect.right + 8;
          break;
      }
  
      this.popover.style.top = `${top + window.scrollY}px`;
      this.popover.style.left = `${left + window.scrollX}px`;
    }
  
    show(e, trigger) {
      this.createPopover(trigger);
    }
  
    hide() {
      if (this.popover) {
        this.popover.remove();
        this.popover = null;
      }
    }
  
    toggle(e, trigger) {
      if (this.popover) {
        this.hide();
      } else {
        this.show(e, trigger);
      }
    }
  }
  
  
  
  