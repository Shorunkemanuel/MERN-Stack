/* Scrollspy.js */

export class Scrollspy {
    constructor(containerSelector, navSelector) {
      this.container = document.querySelector(containerSelector);
      this.navLinks = document.querySelectorAll(`${navSelector} a`);
      this.sections = [];
  
      if (this.container && this.navLinks.length) {
        this.init();
      }
    }
  
    init() {
      // Map nav links to target sections
      this.navLinks.forEach(link => {
        const targetId = link.getAttribute("href").replace("#", "");
        const target = document.getElementById(targetId);
        if (target) {
          this.sections.push({ id: targetId, element: target });
        }
      });
  
      // Attach scroll event
      this.container.addEventListener("scroll", () => this.onScroll());
      this.onScroll(); // Run initially
    }
  
    onScroll() {
      let currentId = null;
      const containerTop = this.container.scrollTop;
  
      for (let section of this.sections) {
        if (section.element.offsetTop - this.container.offsetTop <= containerTop + 10) {
          currentId = section.id;
        }
      }
  
      if (currentId) {
        this.updateActive(currentId);
      }
    }
  
    updateActive(id) {
      this.navLinks.forEach(link => {
        link.classList.remove("active");
        if (link.getAttribute("href") === `#${id}`) {
          link.classList.add("active");
        }
      });
    }
  }
  
  
  
  