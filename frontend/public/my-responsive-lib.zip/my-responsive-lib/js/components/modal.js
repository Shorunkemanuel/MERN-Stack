/* Modal.js */

export class Modal {
    constructor(selector) {
      this.modals = document.querySelectorAll(selector);
  
      this.modals.forEach((modal) => {
        const closeBtn = modal.querySelector("[data-dismiss='modal']");
        const backdrop = modal.querySelector(".modal-backdrop");
  
        // Close when clicking close button
        if (closeBtn) {
          closeBtn.addEventListener("click", () => this.hide(modal));
        }
  
        // Close when clicking backdrop
        if (backdrop) {
          backdrop.addEventListener("click", () => this.hide(modal));
        }
      });
  
      // Close on ESC key
      document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
          this.modals.forEach((modal) => this.hide(modal));
        }
      });
    }
  
    show(modal) {
      modal.classList.add("show");
      document.body.style.overflow = "hidden"; // prevent scrolling
    }
  
    hide(modal) {
      modal.classList.remove("show");
      document.body.style.overflow = ""; // restore scrolling
    }
  }
  
  
  
  