/* Navbar.js */

export class Navbar {
    constructor(selector) {
      this.navbars = document.querySelectorAll(selector);
  
      this.navbars.forEach((navbar) => {
        const toggler = navbar.querySelector(".navbar-toggler");
        const navMenu = navbar.querySelector(".navbar-nav");
  
        if (toggler && navMenu) {
          toggler.addEventListener("click", () => {
            navMenu.classList.toggle("show");
          });
        }
      });
    }
  }
  
  
  
  