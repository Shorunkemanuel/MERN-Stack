/* Spinners.js */

export class Spinner {
    constructor(options = {}) {
      this.size = options.size || "md"; // sm, md, lg
      this.type = options.type || "border"; // border or grow
      this.color = options.color || "primary"; // theme color
    }
  
    create() {
      const el = document.createElement("div");
      if (this.type === "grow") {
        el.className = `spinner-grow spinner-grow-${this.size}`;
      } else {
        el.className = `spinner spinner-${this.size}`;
      }
  
      el.style.setProperty("border-top-color", `var(--color-${this.color}, ${this.color})`);
      el.style.setProperty("background-color", this.type === "grow" ? `var(--color-${this.color}, ${this.color})` : "transparent");
  
      return el;
    }
  
    mount(target) {
      const spinner = this.create();
      document.querySelector(target).appendChild(spinner);
      return spinner;
    }
  }
  
  