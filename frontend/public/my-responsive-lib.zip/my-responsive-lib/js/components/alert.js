/* Alerts.js */

import { on } from "../core/events.js";

/**
 * Initialize dismissible alerts
 */
export function initAlerts() {
  const alerts = document.querySelectorAll(".alert");

  alerts.forEach((alert) => {
    const closeBtn = alert.querySelector(".btn-close");

    if (closeBtn) {
      on(closeBtn, "click", () => {
        alert.classList.add("fade-out");

        // Smooth fade-out effect before removing
        setTimeout(() => {
          alert.remove();
        }, 300);
      });
    }
  });
}



