/* Breadcrumb.js */

/**
 * Add a breadcrumb item dynamically
 * @param {string} selector - Breadcrumb container selector
 * @param {string} label - The text of the breadcrumb item
 * @param {string|null} href - Optional link for the breadcrumb item
 * @param {boolean} isActive - Whether this item is the active (last) item
 */
export function addBreadcrumb(selector, label, href = null, isActive = false) {
    const container = document.querySelector(selector);
    if (!container) return;
  
    const li = document.createElement("li");
    li.classList.add("breadcrumb-item");
  
    if (href && !isActive) {
      const a = document.createElement("a");
      a.href = href;
      a.textContent = label;
      li.appendChild(a);
    } else {
      li.textContent = label;
      if (isActive) li.classList.add("active");
    }
  
    container.appendChild(li);
  }
  
  /**
   * Clear all breadcrumb items
   * @param {string} selector - Breadcrumb container selector
   */
  export function clearBreadcrumb(selector) {
    const container = document.querySelector(selector);
    if (container) container.innerHTML = "";
  }
  
  
  