/* Tables.js */
/* Add basic table utilities like sorting and filtering */

export class Table {
    constructor(tableElement) {
      if (!(tableElement instanceof HTMLElement)) {
        throw new Error("Table requires a valid table element");
      }
      this.table = tableElement;
    }
  
    /**
     * Sort a table column
     * @param {number} columnIndex - The column index to sort
     * @param {boolean} ascending - Sort direction
     */
    sort(columnIndex, ascending = true) {
      const tbody = this.table.querySelector("tbody");
      if (!tbody) return;
  
      const rows = Array.from(tbody.querySelectorAll("tr"));
      const dir = ascending ? 1 : -1;
  
      rows.sort((a, b) => {
        const aText = a.children[columnIndex].innerText.trim();
        const bText = b.children[columnIndex].innerText.trim();
  
        const aNum = parseFloat(aText);
        const bNum = parseFloat(bText);
  
        if (!isNaN(aNum) && !isNaN(bNum)) {
          return (aNum - bNum) * dir;
        }
        return aText.localeCompare(bText) * dir;
      });
  
      rows.forEach(row => tbody.appendChild(row));
    }
  
    /**
     * Filter table rows by keyword
     * @param {string} keyword
     */
    filter(keyword) {
      const rows = this.table.querySelectorAll("tbody tr");
      rows.forEach(row => {
        row.style.display = row.innerText.toLowerCase().includes(keyword.toLowerCase())
          ? ""
          : "none";
      });
    }
  }
  
  
  
  
  