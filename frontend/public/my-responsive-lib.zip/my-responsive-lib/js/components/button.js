/* Buttons.js */

/**
 * Toggle loading state on a button
 * @param {string} selector - Button selector
 * @param {boolean} isLoading - Whether to enable loading
 */
export function setButtonLoading(selector, isLoading = true) {
    const btn = document.querySelector(selector);
    if (!btn) return;
  
    if (isLoading) {
      btn.dataset.originalText = btn.innerHTML;
      btn.innerHTML = `<span class="spinner-border spinner-border-sm" aria-hidden="true"></span> Loading...`;
      btn.disabled = true;
    } else {
      btn.innerHTML = btn.dataset.originalText || "Button";
      btn.disabled = false;
    }
  }
  
  /**
   * Toggle button active state (like toggle buttons)
   * @param {string} selector - Button selector
   */
  export function toggleButtonActive(selector) {
    const btn = document.querySelector(selector);
    if (!btn) return;
    btn.classList.toggle("active");
  }
  
  
  
  