/* Offcanvas.js */

export class Offcanvas {
    constructor(selector) {
      this.triggers = document.querySelectorAll(selector);
  
      this.triggers.forEach(trigger => {
        const targetSelector = trigger.getAttribute("data-bs-target");
        const target = document.querySelector(targetSelector);
  
        if (!target) return;
  
        const backdrop = this._createBackdrop();
  
        trigger.addEventListener("click", (e) => {
          e.preventDefault();
          this.open(target, backdrop);
        });
  
        const closeBtn = target.querySelector("[data-bs-dismiss='offcanvas']");
        if (closeBtn) {
          closeBtn.addEventListener("click", () => this.close(target, backdrop));
        }
  
        backdrop.addEventListener("click", () => this.close(target, backdrop));
      });
    }
  
    _createBackdrop() {
      let backdrop = document.querySelector(".offcanvas-backdrop");
      if (!backdrop) {
        backdrop = document.createElement("div");
        backdrop.classList.add("offcanvas-backdrop");
        document.body.appendChild(backdrop);
      }
      return backdrop;
    }
  
    open(target, backdrop) {
      target.classList.add("show");
      backdrop.classList.add("show");
      document.body.style.overflow = "hidden";
    }
  
    close(target, backdrop) {
      target.classList.remove("show");
      backdrop.classList.remove("show");
      document.body.style.overflow = "";
    }
  }
  
  
  
  