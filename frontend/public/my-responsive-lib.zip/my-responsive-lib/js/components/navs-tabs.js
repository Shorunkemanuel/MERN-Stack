/* NavsTabs.js */

export class NavsTabs {
    constructor(selector) {
      this.navContainers = document.querySelectorAll(selector);
  
      this.navContainers.forEach((nav) => {
        const links = nav.querySelectorAll(".nav-item a");
  
        links.forEach((link) => {
          link.addEventListener("click", (e) => {
            e.preventDefault();
            const targetId = link.getAttribute("data-bs-target");
  
            // deactivate all links
            links.forEach((l) => l.classList.remove("active"));
            link.classList.add("active");
  
            // hide all tab panes
            const tabContainer = document.querySelector(
              link.closest(".nav").dataset.tabContainer
            );
            if (tabContainer) {
              const panes = tabContainer.querySelectorAll(".tab-pane");
              panes.forEach((pane) => pane.classList.remove("active"));
  
              const targetPane = tabContainer.querySelector(targetId);
              if (targetPane) targetPane.classList.add("active");
            }
          });
        });
      });
    }
  }
  
  
  
  