/* Badge.js */

/**
 * Dynamically update a badge's value
 * @param {string} selector - Badge element selector
 * @param {string|number} value - New value for the badge
 */
 export function updateBadge(selector, value) {
    const badge = document.querySelector(selector);
    if (badge) {
      badge.textContent = value;
    }
  }
  
  /**
   * Increment a badge's numeric value
   * @param {string} selector - Badge element selector
   * @param {number} step - Increment step
   */
  export function incrementBadge(selector, step = 1) {
    const badge = document.querySelector(selector);
    if (badge && !isNaN(badge.textContent)) {
      badge.textContent = parseInt(badge.textContent, 10) + step;
    }
  }
  
  /**
   * Decrement a badge's numeric value
   * @param {string} selector - Badge element selector
   * @param {number} step - Decrement step
   */
  export function decrementBadge(selector, step = 1) {
    const badge = document.querySelector(selector);
    if (badge && !isNaN(badge.textContent)) {
      badge.textContent = Math.max(0, parseInt(badge.textContent, 10) - step);
    }
  }
  
  