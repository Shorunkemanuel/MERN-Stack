/* Progress.js */

export class Progress {
    constructor(selector) {
      this.bars = document.querySelectorAll(selector);
    }
  
    set(selector, value) {
      const bar = document.querySelector(selector);
      if (!bar) return;
  
      const percent = Math.min(Math.max(value, 0), 100); // Clamp 0-100
      bar.style.width = percent + "%";
      bar.setAttribute("aria-valuenow", percent);
      bar.textContent = percent + "%";
    }
  
    animate(selector, value, duration = 1000) {
      const bar = document.querySelector(selector);
      if (!bar) return;
  
      let start = 0;
      const target = Math.min(Math.max(value, 0), 100);
      const step = target / (duration / 16);
  
      const animateStep = () => {
        start += step;
        if (start >= target) {
          this.set(selector, target);
          return;
        }
        this.set(selector, start);
        requestAnimationFrame(animateStep);
      };
  
      animateStep();
    }
  }
  
  
  