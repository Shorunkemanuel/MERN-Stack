/* Toasts.js */

export class Toast {
    constructor({ title = "", message = "", type = "info", duration = 3000 } = {}) {
      this.title = title;
      this.message = message;
      this.type = type;
      this.duration = duration;
    }
  
    create() {
      const toast = document.createElement("div");
      toast.className = `toast toast-${this.type}`;
  
      // header
      if (this.title) {
        const header = document.createElement("div");
        header.className = "toast-header";
        header.textContent = this.title;
        toast.appendChild(header);
      }
  
      // body
      const body = document.createElement("div");
      body.className = "toast-body";
      body.textContent = this.message;
      toast.appendChild(body);
  
      // close button
      const close = document.createElement("button");
      close.className = "toast-close";
      close.innerHTML = "&times;";
      close.onclick = () => this.hide(toast);
      toast.appendChild(close);
  
      return toast;
    }
  
    show() {
      let container = document.querySelector(".toast-container");
      if (!container) {
        container = document.createElement("div");
        container.className = "toast-container";
        document.body.appendChild(container);
      }
  
      const toast = this.create();
      container.appendChild(toast);
  
      // auto hide
      setTimeout(() => this.hide(toast), this.duration);
    }
  
    hide(toast) {
      toast.classList.add("hide");
      toast.addEventListener("animationend", () => toast.remove());
    }
  }
  
  
  
  