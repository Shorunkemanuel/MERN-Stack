// Components Index
import "./alerts.js";
import "./badge.js";
import "./breadcrumb.js";
import "./button.js";
import "./button-group.js";
import "./card.js";
import "./carousel.js";
import "./close-button.js";
import "./collapse.js";
import "./dropdown.js";
import "./list-group.js";
import "./modal.js";
import "./navbar.js";
import "./navs-tabs.js";
import "./offcanvas.js";
import "./pagination.js";
import "./placeholder.js";
import "./popover.js";
import "./progress.js";
import "./scrollspy.js";
import "./spinner.js";
import "./toast.js";
import "./tooltip.js";
import "./table.js";
// Add more component JS files here