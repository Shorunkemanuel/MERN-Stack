/* Dropdown.js */

export class Dropdown {
    constructor(selector) {
      this.toggles = document.querySelectorAll(selector);
  
      this.toggles.forEach((toggle) => {
        const menu = toggle.nextElementSibling;
  
        if (!menu || !menu.classList.contains("dropdown-menu")) return;
  
        // Toggle menu
        toggle.addEventListener("click", (e) => {
          e.preventDefault();
          menu.classList.toggle("show");
        });
  
        // Close when clicking outside
        document.addEventListener("click", (e) => {
          if (!toggle.contains(e.target) && !menu.contains(e.target)) {
            menu.classList.remove("show");
          }
        });
      });
    }
  }
  
  
  