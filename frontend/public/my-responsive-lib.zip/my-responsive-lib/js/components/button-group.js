/* ButtonGroup.js */

/**
 * Toggles active button inside a group (like radio buttons but styled)
 * @param {string} groupSelector - CSS selector for button group
 */
export function enableButtonGroupToggle(groupSelector) {
    const group = document.querySelector(groupSelector);
    if (!group) return;
  
    const buttons = group.querySelectorAll(".btn");
    buttons.forEach((btn) => {
      btn.addEventListener("click", () => {
        buttons.forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
      });
    });
  }
  
  
  
  
  