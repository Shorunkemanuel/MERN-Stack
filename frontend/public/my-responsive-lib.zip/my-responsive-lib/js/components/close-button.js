/* CloseButton.js */

export class CloseButton {
    constructor(selector) {
      this.buttons = document.querySelectorAll(selector);
  
      this.buttons.forEach((btn) => {
        btn.addEventListener("click", (e) => {
          const targetSelector = btn.getAttribute("data-target");
          if (targetSelector) {
            const target = document.querySelector(targetSelector);
            if (target) target.remove();
          } else {
            // fallback: remove parent element
            btn.parentElement.remove();
          }
        });
      });
    }
  }
  
  
  