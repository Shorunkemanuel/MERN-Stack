/* Figures.js */
/* Minimal helper for lazy-loading and toggling captions */

export class Figure {
    constructor(figureElement) {
      if (!(figureElement instanceof HTMLElement)) {
        throw new Error("Figure requires a valid element");
      }
      this.figure = figureElement;
      this.image = figureElement.querySelector("img");
      this.caption = figureElement.querySelector(".figure-caption");
  
      this.init();
    }
  
    init() {
      // Lazy load support
      if (this.image && this.image.dataset.src) {
        this.lazyLoad();
      }
    }
  
    lazyLoad() {
      const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            this.image.src = this.image.dataset.src;
            observer.disconnect();
          }
        });
      });
      observer.observe(this.image);
    }
  
    toggleCaption() {
      if (this.caption) {
        this.caption.style.display =
          this.caption.style.display === "none" ? "block" : "none";
      }
    }
  }
  
  
  
  
  
  