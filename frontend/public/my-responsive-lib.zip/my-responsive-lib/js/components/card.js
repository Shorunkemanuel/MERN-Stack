/* Card.js */

/**
 * Simple card toggler (expand/collapse content)
 * @param {string} selector - CSS selector for the card
 */
export function enableCardToggle(selector) {
    const cards = document.querySelectorAll(selector);
    cards.forEach((card) => {
      const header = card.querySelector(".card-header");
      if (!header) return;
  
      header.style.cursor = "pointer";
      header.addEventListener("click", () => {
        card.classList.toggle("collapsed");
        const body = card.querySelector(".card-body");
        if (body) {
          body.style.display = card.classList.contains("collapsed")
            ? "none"
            : "block";
        }
      });
    });
  }
  
  
  