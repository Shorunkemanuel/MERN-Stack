/* Pagination.js */

export class Pagination {
    constructor(selector) {
      this.paginations = document.querySelectorAll(selector);
  
      this.paginations.forEach(pagination => {
        pagination.addEventListener("click", (e) => {
          const target = e.target.closest(".page-link");
          if (!target) return;
  
          const pageItem = target.parentElement;
  
          // Skip if disabled
          if (pageItem.classList.contains("disabled")) return;
  
          // Remove active from all
          pagination.querySelectorAll(".page-item").forEach(item => {
            item.classList.remove("active");
          });
  
          // Add active to clicked
          pageItem.classList.add("active");
  
          // Dispatch custom event
          const event = new CustomEvent("pageChange", {
            detail: { page: target.textContent.trim() }
          });
          pagination.dispatchEvent(event);
        });
      });
    }
  }
  
  
  