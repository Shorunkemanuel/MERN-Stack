/* Placeholders.js */

export class Placeholders {
    constructor() {
      this.active = true;
    }
  
    toggle(selector, state) {
      const elements = document.querySelectorAll(selector);
  
      elements.forEach(el => {
        if (state) {
          el.classList.add("placeholder");
        } else {
          el.classList.remove("placeholder");
        }
      });
    }
  
    apply(selector, type = "glow") {
      const elements = document.querySelectorAll(selector);
  
      elements.forEach(el => {
        el.classList.add("placeholder");
  
        if (type === "wave") {
          el.classList.add("placeholder-wave");
        } else {
          // default is glow
          el.classList.remove("placeholder-wave");
        }
      });
    }
  
    clear(selector) {
      const elements = document.querySelectorAll(selector);
  
      elements.forEach(el => {
        el.classList.remove("placeholder", "placeholder-wave");
      });
    }
  }
  
  