/* Collapse.js */

export class Collapse {
    constructor(triggerSelector) {
      this.triggers = document.querySelectorAll(triggerSelector);
  
      this.triggers.forEach((trigger) => {
        const targetSelector = trigger.getAttribute("data-target");
        const target = document.querySelector(targetSelector);
  
        if (!target) return;
  
        trigger.addEventListener("click", () => {
          const isShown = target.classList.contains("show");
  
          // Hide any currently open collapses if needed
          if (trigger.hasAttribute("data-parent")) {
            const parent = document.querySelector(trigger.getAttribute("data-parent"));
            if (parent) {
              parent.querySelectorAll(".collapse.show").forEach((openEl) => {
                if (openEl !== target) openEl.classList.remove("show");
              });
            }
          }
  
          // Toggle this one
          target.classList.toggle("show", !isShown);
        });
      });
    }
  }
  
  
  
  
  
  