/* stringHelpers.js */

export const capitalize = (str) => str.charAt(0).toUpperCase() + str.slice(1);
export const slugify = (str) =>
  str.toLowerCase().trim().replace(/\s+/g, "-").replace(/[^\w-]+/g, "");
export const truncate = (str, len = 100) =>
  str.length > len ? str.substring(0, len) + "…" : str;
export const toCamel = (str) =>
  str.replace(/-./g, (m) => m[1].toUpperCase());
export const toKebab = (str) =>
  str.replace(/[A-Z]/g, (m) => "-" + m.toLowerCase()).replace(/^-/, "");
  
  
  
