  /* numberHelpers.js */

  export const clamp = (num, min, max) => Math.min(Math.max(num, min), max);
  export const randomInt = (min, max) =>
    Math.floor(Math.random() * (max - min + 1)) + min;
  export const randomFloat = (min, max) =>
    Math.random() * (max - min) + min;
  export const formatNumber = (num, locale = "en-US") =>
    new Intl.NumberFormat(locale).format(num);
  
  
  