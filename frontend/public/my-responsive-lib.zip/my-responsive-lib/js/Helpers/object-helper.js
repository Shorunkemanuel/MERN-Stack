/* objectHelpers.js */

export const deepClone = (obj) => JSON.parse(JSON.stringify(obj));
export const merge = (target, source) => ({ ...target, ...source });
export const get = (obj, path, fallback = undefined) =>
  path.split(".").reduce((acc, key) => (acc ? acc[key] : fallback), obj);
  
  
  
