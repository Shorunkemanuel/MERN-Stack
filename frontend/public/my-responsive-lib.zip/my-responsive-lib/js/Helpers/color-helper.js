 /* colorHelpers.js */

 export const hexToRgb = (hex) => {
    const h = hex.replace("#", "");
    const bigint = parseInt(h, 16);
    return {
      r: (bigint >> 16) & 255,
      g: (bigint >> 8) & 255,
      b: bigint & 255,
    };
  };
  
  export const rgbToHex = (r, g, b) =>
    "#" +
    [r, g, b].map((x) => x.toString(16).padStart(2, "0")).join("");
  
  export const getContrastYIQ = (hex) => {
    const { r, g, b } = hexToRgb(hex);
    return (r * 299 + g * 587 + b * 114) / 1000 >= 128 ? "black" : "white";
  };
  
  
  
  
  