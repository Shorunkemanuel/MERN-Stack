/* arrayHelpers.js */

export const unique = (arr) => [...new Set(arr)];
export const chunk = (arr, size) =>
  Array.from({ length: Math.ceil(arr.length / size) }, (_, i) =>
    arr.slice(i * size, i * size + size)
  );
export const flatten = (arr) => arr.reduce((a, b) => a.concat(b), []);
export const removeFalsy = (arr) => arr.filter(Boolean);

