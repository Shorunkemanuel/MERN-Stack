/* domHelpers.js */

export const $ = (selector, scope = document) => scope.querySelector(selector);
export const $$ = (selector, scope = document) => scope.querySelectorAll(selector);

export const createEl = (tag, options = {}) => {
  const el = document.createElement(tag);
  if (options.class) el.className = options.class;
  if (options.html) el.innerHTML = options.html;
  if (options.attrs) {
    Object.entries(options.attrs).forEach(([k, v]) => el.setAttribute(k, v));
  }
  return el;
};

export const on = (el, event, handler) => el.addEventListener(event, handler);
export const off = (el, event, handler) => el.removeEventListener(event, handler);



