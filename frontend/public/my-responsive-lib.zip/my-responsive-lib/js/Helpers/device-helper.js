 /* deviceHelpers.js */

 export const isMobile = () => /Mobi|Android/i.test(navigator.userAgent);
 export const isTablet = () => /Tablet|iPad/i.test(navigator.userAgent);
 export const isDesktop = () => !isMobile() && !isTablet();
 
 export const getBrowser = () => {
   const ua = navigator.userAgent;
   if (/chrome|crios|crmo/i.test(ua)) return "Chrome";
   if (/firefox|fxios/i.test(ua)) return "Firefox";
   if (/safari/i.test(ua)) return "Safari";
   if (/msie|trident/i.test(ua)) return "IE";
   if (/edg/i.test(ua)) return "Edge";
   return "Unknown";
 };
 
 export const getOS = () => {
   const ua = navigator.userAgent;
   if (/windows/i.test(ua)) return "Windows";
   if (/mac os/i.test(ua)) return "MacOS";
   if (/android/i.test(ua)) return "Android";
   if (/linux/i.test(ua)) return "Linux";
   if (/iphone|ipad|ipod/i.test(ua)) return "iOS";
   return "Unknown";
 };
 
 
 
 