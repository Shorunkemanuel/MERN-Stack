/* breakpoints.js
   Core breakpoint utilities for responsive JS behavior
   Works with the same values defined in /css/core/variables.css
*/

/* Define breakpoints (should match CSS variables) */
export const breakpoints = {
    xs: 320,
    sm: 480,
    md: 768,
    lg: 1024,
    xl: 1280,
    xxl: 1536,
  };
  
  /* 🔍 Match media query */
  export const matchBreakpoint = (bp, type = "min") => {
    const size = breakpoints[bp];
    if (!size) {
      console.warn(`⚠️ Breakpoint "${bp}" not defined`);
      return false;
    }
    const query = type === "max"
      ? `(max-width: ${size - 1}px)`
      : `(min-width: ${size}px)`;
    return window.matchMedia(query).matches;
  };
  
  /* 📡 Watch breakpoint changes */
  export const onBreakpointChange = (bp, callback, type = "min") => {
    const size = breakpoints[bp];
    if (!size) return;
  
    const query = type === "max"
      ? `(max-width: ${size - 1}px)`
      : `(min-width: ${size}px)`;
  
    const mql = window.matchMedia(query);
  
    // Initial check
    if (mql.matches) callback(true);
  
    // Listen for changes
    const handler = (e) => callback(e.matches);
    mql.addEventListener("change", handler);
  
    return () => mql.removeEventListener("change", handler); // unsubscribe
  };
  
  /* 🛠️ Current breakpoint helper */
  export const currentBreakpoint = () => {
    const width = window.innerWidth;
    let active = "xs";
    for (const [key, size] of Object.entries(breakpoints)) {
      if (width >= size) active = key;
    }
    return active;
  };
  
  
  
  
  