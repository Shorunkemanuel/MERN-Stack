/* accessibility.js

   Accessibility & focus management utilities

*/


/**

 * Trap focus within a given element (e.g., modal, drawer).

 * @param {HTMLElement} container - The element to trap focus inside.

 */

export const trapFocus = (container) => {

    const focusableSelectors = `
    
        a[href], area[href], input:not([disabled]):not([type="hidden"]),
    
        select:not([disabled]), textarea:not([disabled]),
    
        button:not([disabled]), iframe, object, embed,
    
        [contenteditable], [tabindex]:not([tabindex="-1"])
    
      `;


    const focusableEls = container.querySelectorAll(focusableSelectors);

    if (!focusableEls.length) return;


    const firstEl = focusableEls[0];

    const lastEl = focusableEls[focusableEls.length - 1];


    const handleFocusTrap = (e) => {

        if (e.key !== "Tab") return;


        if (e.shiftKey) {

            // Shift + Tab

            if (document.activeElement === firstEl) {

                e.preventDefault();

                lastEl.focus();

            }

        } else {

            // Tab only

            if (document.activeElement === lastEl) {

                e.preventDefault();

                firstEl.focus();

            }

        }

    };


    container.addEventListener("keydown", handleFocusTrap);


    // Return cleanup

    return () => {

        container.removeEventListener("keydown", handleFocusTrap);

    };

};


/**
 
 * Move focus to a target element.
 
 * @param {HTMLElement|string} el - The element or selector to focus.
 
 */

export const focusElement = (el) => {

    const target = typeof el === "string" ? document.querySelector(el) : el;

    if (target && typeof target.focus === "function") {

        target.setAttribute("tabindex", "-1");

        target.focus();

    }

};


/**
 
 * Add ARIA attributes safely.
 
 * @param {HTMLElement} el
 
 * @param {Object} attrs - key/value pairs of ARIA attributes
 
 */

export const setAria = (el, attrs = {}) => {

    Object.entries(attrs).forEach(([key, value]) => {

        el.setAttribute(`aria-${key}`, value);

    });

};


/**
 
 * Remove ARIA attributes.
 
 * @param {HTMLElement} el
 
 * @param {Array} keys - List of aria-* attributes (without "aria-")
 
 */

export const removeAria = (el, keys = []) => {

    keys.forEach((key) => el.removeAttribute(`aria-${key}`));

};


/**
 
 * Announce a message for screen readers (ARIA live region).
 
 * @param {string} message
 
 * @param {string} politeness - "polite" or "assertive"
 
 */

export const announce = (message, politeness = "polite") => {

    let liveRegion = document.getElementById("sr-live-region");

    if (!liveRegion) {

        liveRegion = document.createElement("div");

        liveRegion.id = "sr-live-region";

        liveRegion.setAttribute("aria-live", politeness);

        liveRegion.setAttribute("aria-atomic", "true");

        liveRegion.style.position = "absolute";

        liveRegion.style.width = "1px";

        liveRegion.style.height = "1px";

        liveRegion.style.overflow = "hidden";

        liveRegion.style.clip = "rect(0 0 0 0)";

        document.body.appendChild(liveRegion);

    }

    liveRegion.textContent = message;

};



