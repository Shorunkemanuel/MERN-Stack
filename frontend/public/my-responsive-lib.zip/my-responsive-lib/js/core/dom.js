/* dom.js
   Core DOM utilities for the library
   Inspired by jQuery-like helpers but lightweight and vanilla
*/

/* 🔍 Query helpers */
export const qs = (selector, scope = document) => scope.querySelector(selector);
export const qsa = (selector, scope = document) => [...scope.querySelectorAll(selector)];

/* 🧩 Element creation */
export const createEl = (tag, options = {}) => {
  const el = document.createElement(tag);
  if (options.class) el.className = options.class;
  if (options.id) el.id = options.id;
  if (options.attrs) {
    Object.entries(options.attrs).forEach(([attr, value]) => {
      el.setAttribute(attr, value);
    });
  }
  if (options.html) el.innerHTML = options.html;
  return el;
};

/* 🎯 Class manipulation */
export const addClass = (el, className) => el.classList.add(className);
export const removeClass = (el, className) => el.classList.remove(className);
export const toggleClass = (el, className) => el.classList.toggle(className);
export const hasClass = (el, className) => el.classList.contains(className);

/* 🛠️ Attributes */
export const setAttr = (el, name, value) => el.setAttribute(name, value);
export const getAttr = (el, name) => el.getAttribute(name);
export const removeAttr = (el, name) => el.removeAttribute(name);

/* 📦 Content */
export const setHTML = (el, html) => (el.innerHTML = html);
export const setText = (el, text) => (el.textContent = text);

/* 🎧 Event helpers */
export const on = (el, event, handler, opts = false) => el.addEventListener(event, handler, opts);
export const off = (el, event, handler, opts = false) => el.removeEventListener(event, handler, opts);

/* 🔄 DOM ready */
export const ready = (fn) => {
  if (document.readyState !== "loading") {
    fn();
  } else {
    document.addEventListener("DOMContentLoaded", fn);
  }
};

/* 🧹 Remove element */
export const removeEl = (el) => el && el.parentNode && el.parentNode.removeChild(el);

/* ➕ Insert helpers */
export const insertAfter = (newNode, referenceNode) => {
  referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);
};

export const insertBefore = (newNode, referenceNode) => {
  referenceNode.parentNode.insertBefore(newNode, referenceNode);
};

/* 📦 Wrapping */
export const wrapEl = (el, wrapper) => {
  el.parentNode.insertBefore(wrapper, el);
  wrapper.appendChild(el);
};

export const unwrapEl = (el) => {
  const parent = el.parentNode;
  if (parent !== document.body) {
    parent.replaceWith(...parent.childNodes);
  }
};

/* 📍 Position helpers */
export const getOffset = (el) => {
  const rect = el.getBoundingClientRect();
  return {
    top: rect.top + window.scrollY,
    left: rect.left + window.scrollX,
    width: rect.width,
    height: rect.height,
  };
};

/* 🔄 Toggle attribute */
export const toggleAttr = (el, name, value = "") => {
  if (el.hasAttribute(name)) {
    el.removeAttribute(name);
  } else {
    el.setAttribute(name, value);
  }
};

/* 🔎 Find closest ancestor */
export const closest = (el, selector) => el.closest(selector);



