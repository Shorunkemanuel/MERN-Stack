/* domReady.js
   Lightweight DOM lifecycle utilities
*/

/**
 * Run a callback when the DOM is fully loaded (DOMContentLoaded).
 * @param {Function} callback - Function to run once DOM is ready.
 */
export const domReady = (callback) => {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", callback);
    } else {
      callback();
    }
  };
  
  /**
   * Run a callback after window has fully loaded (including images, iframes, etc.)
   * @param {Function} callback
   */
  export const onWindowLoad = (callback) => {
    if (document.readyState === "complete") {
      callback();
    } else {
      window.addEventListener("load", callback);
    }
  };
  
  /**
   * Run a callback when the DOM is updated with new nodes (MutationObserver).
   * Useful for dynamic components.
   * @param {Node} target - The DOM node to observe (default: document.body).
   * @param {Function} callback - Function triggered when DOM changes.
   */
  export const onDomChange = (callback, target = document.body) => {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => callback(mutation));
    });
  
    observer.observe(target, {
      childList: true,
      subtree: true,
    });
  
    return observer; // so it can be disconnected later
  };
  
  /**
   * Run a callback when the DOM is fully interactive (document.readyState = 'interactive').
   * Slightly earlier than DOMContentLoaded but safe for most scripts.
   * @param {Function} callback
   */
  export const onDomInteractive = (callback) => {
    if (document.readyState === "interactive" || document.readyState === "complete") {
      callback();
    } else {
      document.addEventListener("readystatechange", () => {
        if (document.readyState === "interactive") {
          callback();
        }
      });
    }
  };
  
  
  
  