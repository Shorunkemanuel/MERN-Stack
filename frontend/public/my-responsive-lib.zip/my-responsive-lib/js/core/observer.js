/* observer.js
   Utility wrappers for IntersectionObserver & MutationObserver
*/

/**
 * Observe visibility of elements in viewport
 * @param {Element|NodeList|string} targets - Selector, single element, or NodeList
 * @param {Function} callback - Called when element enters/exits viewport
 * @param {Object} options - root, rootMargin, threshold
 * @returns {IntersectionObserver}
 */
export function observeVisibility(targets, callback, options = {}) {
    const defaultOptions = {
      root: null,
      rootMargin: "0px",
      threshold: 0.1, // 10% visibility
    };
  
    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach((entry) => callback(entry, obs));
    }, { ...defaultOptions, ...options });
  
    if (typeof targets === "string") {
      targets = document.querySelectorAll(targets);
    } else if (targets instanceof Element) {
      targets = [targets];
    }
  
    targets.forEach((el) => observer.observe(el));
    return observer;
  }
  
  /**
   * Observe DOM mutations
   * @param {Element|string} target - Selector or single element
   * @param {Function} callback - Called on mutations
   * @param {Object} options - childList, attributes, subtree, etc.
   * @returns {MutationObserver}
   */
  export function observeMutations(target, callback, options = {}) {
    const defaultOptions = {
      childList: true,
      subtree: true,
      attributes: true,
    };
  
    const observer = new MutationObserver((mutations, obs) => {
      callback(mutations, obs);
    });
  
    if (typeof target === "string") {
      target = document.querySelector(target);
    }
  
    if (target) {
      observer.observe(target, { ...defaultOptions, ...options });
    }
  
    return observer;
  }
  
  /**
   * Disconnect an observer safely
   * @param {IntersectionObserver|MutationObserver} observer 
   */
  export function disconnectObserver(observer) {
    if (observer && typeof observer.disconnect === "function") {
      observer.disconnect();
    }
  }
  
  
  