/* ajax.js

   Lightweight fetch wrapper for GET, POST, PUT, DELETE, and form handling

*/


/**

 * Core request function

 * @param {string} url

 * @param {Object} options

 * @returns {Promise<any>}

 */

export const request = async (url, options = {}) => {

    try {

        const res = await fetch(url, options);

        const contentType = res.headers.get("content-type");


        if (!res.ok) {

            throw new Error(`HTTP ${res.status} - ${res.statusText}`);

        }


        if (contentType && contentType.includes("application/json")) {

            return await res.json();

        }

        return await res.text();

    } catch (err) {

        console.error("AJAX Request Error:", err);

        throw err;

    }

};


/**
 
 * GET request
 
 * @param {string} url
 
 * @param {Object} headers
 
 */

export const get = (url, headers = {}) =>

    request(url, {

        method: "GET",

        headers: { "Content-Type": "application/json", ...headers },

    });


/**
 
 * POST request with JSON
 
 * @param {string} url
 
 * @param {Object} data
 
 * @param {Object} headers
 
 */

export const post = (url, data = {}, headers = {}) =>

    request(url, {

        method: "POST",

        headers: { "Content-Type": "application/json", ...headers },

        body: JSON.stringify(data),

    });


/**
 
 * PUT request with JSON
 
 * @param {string} url
 
 * @param {Object} data
 
 * @param {Object} headers
 
 */

export const put = (url, data = {}, headers = {}) =>

    request(url, {

        method: "PUT",

        headers: { "Content-Type": "application/json", ...headers },

        body: JSON.stringify(data),

    });


/**
 
 * DELETE request
 
 * @param {string} url
 
 * @param {Object} headers
 
 */

export const del = (url, headers = {}) =>

    request(url, {

        method: "DELETE",

        headers: { "Content-Type": "application/json", ...headers },

    });


/**
 
 * Submit form with FormData (auto handles file uploads).
 
 * @param {HTMLFormElement} form
 
 * @param {string} url
 
 * @param {string} method
 
 */

export const submitForm = (form, url, method = "POST") => {

    const formData = new FormData(form);


    return request(url, {

        method,

        body: formData,

    });

};


/**
 
 * Load HTML snippet (like AJAX partials).
 
 * @param {string} url
 
 * @param {string} selector
 
 */

export const loadHTML = async (url, selector) => {

    const html = await request(url);

    const container = document.querySelector(selector);

    if (container) container.innerHTML = html;

    return container;

};




