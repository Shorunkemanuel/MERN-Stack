/**
 * Core Typography Helpers
 * Dynamic font size, responsive scaling, etc.
 */

export function setFontSize(element, size) {
    const el = typeof element === "string" ? document.querySelector(element) : element;
    if (el) el.style.fontSize = size;
  }
  
  export function setLineHeight(element, height) {
    const el = typeof element === "string" ? document.querySelector(element) : element;
    if (el) el.style.lineHeight = height;
  }
  
  export function setFontWeight(element, weight) {
    const el = typeof element === "string" ? document.querySelector(element) : element;
    if (el) el.style.fontWeight = weight;
  }
  
  