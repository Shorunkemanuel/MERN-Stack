/* events.js
   Core event utilities for the library
   Lightweight event delegation & helpers
*/

/* 🎧 Delegate event
   Example: delegate(document, '.btn', 'click', e => console.log(e.target));
*/
export const delegate = (root, selector, event, handler) => {
    root.addEventListener(event, (e) => {
      if (e.target.closest(selector)) {
        handler(e, e.target.closest(selector));
      }
    });
  };
  
  /* 🔄 One-time event listener */
  export const once = (el, event, handler, opts = false) => {
    const fn = (e) => {
      handler(e);
      el.removeEventListener(event, fn, opts);
    };
    el.addEventListener(event, fn, opts);
  };
  
  /* ⏱ Debounce (wait until user stops) */
  export const debounce = (fn, delay = 200) => {
    let timer;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), delay);
    };
  };
  
  /* ⚡ Throttle (limit execution rate) */
  export const throttle = (fn, limit = 200) => {
    let waiting = false;
    return (...args) => {
      if (!waiting) {
        fn.apply(this, args);
        waiting = true;
        setTimeout(() => (waiting = false), limit);
      }
    };
  };
  
  /* 🖱 Outside click (for modals, dropdowns) */
  export const onClickOutside = (element, callback) => {
    const handler = (e) => {
      if (!element.contains(e.target)) {
        callback(e);
        document.removeEventListener("click", handler);
      }
    };
    document.addEventListener("click", handler);
  };
  
  /* ⌨️ Keyboard shortcuts */
  export const onKey = (key, handler) => {
    document.addEventListener("keydown", (e) => {
      if (e.key === key) handler(e);
    });
  };
  
  
  
  
  