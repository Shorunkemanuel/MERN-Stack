js/core/logger.js



/* logger.js
   Centralized logging utility for debugging and production control
*/

const LOG_LEVELS = {
  DEBUG: 0,
  INFO: 1,
  WARN: 2,
  ERROR: 3,
  NONE: 4,
};

let currentLevel = LOG_LEVELS.DEBUG; // default: log everything

/**
 * Set the global log level
 * @param {string} level - "debug" | "info" | "warn" | "error" | "none"
 */
export const setLogLevel = (level) => {
  const upper = level.toUpperCase();
  if (LOG_LEVELS[upper] !== undefined) {
    currentLevel = LOG_LEVELS[upper];
  } else {
    console.warn(`[Logger] Invalid log level: ${level}`);
  }
};

/**
 * Generic logger
 * @param {string} level
 * @param  {...any} args
 */
const log = (level, ...args) => {
  if (LOG_LEVELS[level] >= currentLevel) return;

  const timestamp = new Date().toISOString();
  const prefix = `[${level}] ${timestamp}:`;

  switch (level) {
    case "DEBUG":
      console.debug(prefix, ...args);
      break;
    case "INFO":
      console.info(prefix, ...args);
      break;
    case "WARN":
      console.warn(prefix, ...args);
      break;
    case "ERROR":
      console.error(prefix, ...args);
      break;
  }
};

// Exposed API
export const debug = (...args) => log("DEBUG", ...args);
export const info = (...args) => log("INFO", ...args);
export const warn = (...args) => log("WARN", ...args);
export const error = (...args) => log("ERROR", ...args);

export const logger = {
  setLevel: setLogLevel,
  debug,
  info,
  warn,
  error,
};

