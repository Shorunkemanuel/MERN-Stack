/* helper.js

   General-purpose utility helpers

*/


/**

 * Generate a unique ID with optional prefix.

 * @param {string} prefix

 * @returns {string}

 */

export const uid = (prefix = "id") => {

    return `${prefix}-${Math.random().toString(36).substr(2, 9)}`;

};


/**
 
 * Debounce function (runs after wait time has passed since last call).
 
 * @param {Function} fn
 
 * @param {number} delay
 
 * @returns {Function}
 
 */

export const debounce = (fn, delay = 200) => {

    let timeout;

    return (...args) => {

        clearTimeout(timeout);

        timeout = setTimeout(() => fn.apply(this, args), delay);

    };

};


/**
 
 * Throttle function (runs at most once per wait time).
 
 * @param {Function} fn
 
 * @param {number} limit
 
 * @returns {Function}
 
 */

export const throttle = (fn, limit = 200) => {

    let inThrottle;

    return (...args) => {

        if (!inThrottle) {

            fn.apply(this, args);

            inThrottle = true;

            setTimeout(() => (inThrottle = false), limit);

        }

    };

};


/**
 
 * Clamp a number between min and max.
 
 * @param {number} value
 
 * @param {number} min
 
 * @param {number} max
 
 * @returns {number}
 
 */

export const clamp = (value, min, max) => {

    return Math.min(Math.max(value, min), max);

};


/**
 
 * Check if a value is an object.
 
 * @param {*} val
 
 * @returns {boolean}
 
 */

export const isObject = (val) =>

    val !== null && typeof val === "object" && !Array.isArray(val);


/**
 
 * Deep merge two objects.
 
 * @param {Object} target
 
 * @param {Object} source
 
 * @returns {Object}
 
 */

export const deepMerge = (target, source) => {

    const output = { ...target };

    if (isObject(target) && isObject(source)) {

        Object.keys(source).forEach((key) => {

            if (isObject(source[key])) {

                if (!(key in target)) Object.assign(output, { [key]: source[key] });

                else output[key] = deepMerge(target[key], source[key]);

            } else {

                Object.assign(output, { [key]: source[key] });

            }

        });

    }

    return output;

};


/**
 
 * Shuffle array (Fisher–Yates algorithm).
 
 * @param {Array} arr
 
 * @returns {Array}
 
 */

export const shuffle = (arr) => {

    let array = [...arr];

    for (let i = array.length - 1; i > 0; i--) {

        const j = Math.floor(Math.random() * (i + 1));

        [array[i], array[j]] = [array[j], array[i]];

    }

    return array;

};


/**
 
 * Capitalize first letter of a string.
 
 * @param {string} str
 
 * @returns {string}
 
 */

export const capitalize = (str) =>

    str.charAt(0).toUpperCase() + str.slice(1);


/**
 
 * Convert string to kebab-case.
 
 * @param {string} str
 
 * @returns {string}
 
 */

export const kebabCase = (str) =>

    str

        .replace(/([a-z])([A-Z])/g, "$1-$2")

        .replace(/\s+/g, "-")

        .toLowerCase();


/**
 
 * Get random integer between min and max (inclusive).
 
 * @param {number} min
 
 * @param {number} max
 
 * @returns {number}
 
 */

export const randomInt = (min, max) =>

    Math.floor(Math.random() * (max - min + 1)) + min;



