/* router.js
   Lightweight client-side router
   Supports hash-based and history-based routing
*/

export class Router {
    constructor(options = {}) {
      this.routes = {};
      this.mode = options.mode === "history" && !!(history.pushState) 
        ? "history" 
        : "hash"; // fallback to hash
      this.root = options.root ? "/" + this.clearSlashes(options.root) + "/" : "/";
      this.current = null;
    }
  
    add(path, handler) {
      this.routes[path] = handler;
      return this;
    }
  
    remove(path) {
      delete this.routes[path];
      return this;
    }
  
    clearSlashes(path) {
      return path.toString().replace(/\/$/, "").replace(/^\//, "");
    }
  
    getFragment() {
      if (this.mode === "history") {
        let fragment = this.clearSlashes(
          decodeURI(location.pathname + location.search)
        );
        fragment = fragment.replace(/\?(.*)$/, "");
        fragment = this.root != "/" ? fragment.replace(this.root, "") : fragment;
        return this.clearSlashes(fragment);
      } else {
        const match = window.location.href.match(/#(.*)$/);
        return match ? this.clearSlashes(match[1]) : "";
      }
    }
  
    navigate(path = "") {
      if (this.mode === "history") {
        history.pushState(null, null, this.root + this.clearSlashes(path));
      } else {
        window.location.hash = path;
      }
      return this;
    }
  
    listen() {
      clearInterval(this.interval);
      this.interval = setInterval(this.check.bind(this), 50);
      return this;
    }
  
    check() {
      const fragment = this.getFragment();
      if (this.current === fragment) return;
  
      this.current = fragment;
      if (typeof this.routes[fragment] === "function") {
        this.routes[fragment]();
      } else if (typeof this.routes["*"] === "function") {
        this.routes["*"](); // wildcard fallback
      }
    }
  }
  
  