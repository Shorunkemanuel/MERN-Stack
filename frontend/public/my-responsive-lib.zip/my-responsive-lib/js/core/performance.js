/* performance.js
   Utilities for measuring app performance
*/

/**
 * Measure time taken by a synchronous function
 * @param {Function} fn - Function to measure
 * @param  {...any} args - Arguments to pass to function
 * @returns {Object} { result, time }
 */
export function measureExecution(fn, ...args) {
    const start = performance.now();
    const result = fn(...args);
    const end = performance.now();
    return {
      result,
      time: end - start
    };
  }
  
  /**
   * Measure async function execution time
   * @param {Function} fn - Async function
   * @param  {...any} args
   * @returns {Promise<Object>} { result, time }
   */
  export async function measureExecutionAsync(fn, ...args) {
    const start = performance.now();
    const result = await fn(...args);
    const end = performance.now();
    return {
      result,
      time: end - start
    };
  }
  
  /**
   * Get page load performance metrics
   * @returns {Object}
   */
  export function getPagePerformance() {
    if (!performance || !performance.timing) return {};
  
    const timing = performance.timing;
    return {
      dnsLookup: timing.domainLookupEnd - timing.domainLookupStart,
      tcpHandshake: timing.connectEnd - timing.connectStart,
      ttfb: timing.responseStart - timing.requestStart,
      response: timing.responseEnd - timing.responseStart,
      domInteractive: timing.domInteractive - timing.navigationStart,
      pageLoad: timing.loadEventEnd - timing.navigationStart
    };
  }
  
  /**
   * Simple FPS monitor
   * @param {Function} callback - Called with FPS value
   */
  export function monitorFPS(callback) {
    let lastFrame = performance.now();
    let frameCount = 0;
  
    function loop(now) {
      frameCount++;
      if (now - lastFrame >= 1000) {
        callback(frameCount);
        frameCount = 0;
        lastFrame = now;
      }
      requestAnimationFrame(loop);
    }
  
    requestAnimationFrame(loop);
  }
  
  /**
   * Custom timer utility
   */
  export class Timer {
    constructor() {
      this.startTime = null;
      this.endTime = null;
    }
  
    start() {
      this.startTime = performance.now();
    }
  
    stop() {
      this.endTime = performance.now();
      return this.endTime - this.startTime;
    }
  
    reset() {
      this.startTime = null;
      this.endTime = null;
    }
  }
  
  
  
  