core/i18n.js


/* i18n.js
   Simple internationalization (i18n) utility
*/

const translations = {};
let currentLang = "en";

/**
 * Add translations for a specific language
 * @param {string} lang - Language code (e.g., "en", "fr")
 * @param {object} data - Key-value pairs for translations
 */
export function addTranslations(lang, data) {
  if (!translations[lang]) translations[lang] = {};
  Object.assign(translations[lang], data);
}

/**
 * Set the active language
 * @param {string} lang
 */
export function setLanguage(lang) {
  if (!translations[lang]) {
    console.warn(`[i18n] No translations found for: ${lang}`);
  }
  currentLang = lang;
  document.documentElement.lang = lang;
}

/**
 * Get the current language
 * @returns {string}
 */
export function getLanguage() {
  return currentLang;
}

/**
 * Translate a key
 * @param {string} key - Translation key
 * @param {object} [replacements] - Placeholder replacements
 * @returns {string}
 */
export function t(key, replacements = {}) {
  const langSet = translations[currentLang] || {};
  let text = langSet[key] || key;

  // Replace placeholders like {name}
  for (const [placeholder, value] of Object.entries(replacements)) {
    text = text.replace(new RegExp(`{${placeholder}}`, "g"), value);
  }

  return text;
}

/**
 * Pluralization support
 * @param {string} key - Translation key (should contain "one" & "other")
 * @param {number} count
 * @returns {string}
 */
export function plural(key, count) {
  const langSet = translations[currentLang] || {};
  const forms = langSet[key];
  if (!forms) return key;

  let template = count === 1 ? forms.one : forms.other;
  return template.replace("{count}", count);
}



