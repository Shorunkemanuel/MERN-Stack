/* storage.js
   Safe wrapper around localStorage and sessionStorage
   Provides JSON support, fallbacks, and namespaces
*/

const isStorageAvailable = (type) => {
  try {
    const storage = window[type];
    const testKey = "__storage_test__";
    storage.setItem(testKey, "1");
    storage.removeItem(testKey);
    return true;
  } catch (e) {
    return false;
  }
};

/* Choose storage type */
const getStorage = (type = "local") => {
  if (type === "session" && isStorageAvailable("sessionStorage")) {
    return window.sessionStorage;
  }
  if (isStorageAvailable("localStorage")) {
    return window.localStorage;
  }
  // Fallback (in-memory object)
  console.warn("⚠️ Storage not available, using fallback object.");
  return {
    _data: {},
    setItem(k, v) { this._data[k] = v; },
    getItem(k) { return this._data[k] || null; },
    removeItem(k) { delete this._data[k]; },
    clear() { this._data = {}; },
  };
};

/* Save string or object */
export const setStorage = (key, value, type = "local") => {
  const storage = getStorage(type);
  const data = typeof value === "string" ? value : JSON.stringify(value);
  storage.setItem(key, data);
};

/* Read string or parsed object */
export const getStorage = (key, type = "local") => {
  const storage = getStorage(type);
  const value = storage.getItem(key);
  try {
    return JSON.parse(value);
  } catch {
    return value;
  }
};

/* Remove key */
export const removeStorage = (key, type = "local") => {
  const storage = getStorage(type);
  storage.removeItem(key);
};

/* Clear all */
export const clearStorage = (type = "local") => {
  const storage = getStorage(type);
  storage.clear();
};

/* Check if key exists */
export const hasStorage = (key, type = "local") => {
  return getStorage(type).getItem(key) !== null;
};