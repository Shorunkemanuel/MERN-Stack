/**
 * Core Animations Helpers
 * Apply CSS animations programmatically
 */

export const animateCSS = (element, animation, prefix = 'animate__') =>
  new Promise((resolve) => {
    const node = typeof element === "string" ? document.querySelector(element) : element;
    if (!node) return resolve();

    const animationName = `${prefix}${animation}`;
    node.classList.add(animationName);

    function handleAnimationEnd(event) {
      event.stopPropagation();
      node.classList.remove(animationName);
      resolve('Animation ended');
    }

    node.addEventListener('animationend', handleAnimationEnd, { once: true });
  });
  
  














/* animation.js
   Reusable animation helpers (fade, slide, expand/collapse)
   Works with CSS transitions
*/

/* ⏱ Default timing */
// const DEFAULT_DURATION = 300;
// const DEFAULT_EASING = "ease";

// /* 🎭 Fade In */
// export const fadeIn = (el, duration = DEFAULT_DURATION) => {
//   if (!el) return;
//   el.style.opacity = 0;
//   el.style.display = getComputedStyle(el).display === "none" ? "block" : el.style.display;
//   el.style.transition = `opacity ${duration}ms ${DEFAULT_EASING}`;

//   requestAnimationFrame(() => {
//     el.style.opacity = 1;
//   });

//   setTimeout(() => {
//     el.style.transition = "";
//   }, duration);
// };

// /* 🎭 Fade Out */
// export const fadeOut = (el, duration = DEFAULT_DURATION) => {
//   if (!el) return;
//   el.style.opacity = 1;
//   el.style.transition = `opacity ${duration}ms ${DEFAULT_EASING}`;

//   requestAnimationFrame(() => {
//     el.style.opacity = 0;
//   });

//   setTimeout(() => {
//     el.style.display = "none";
//     el.style.transition = "";
//   }, duration);
// };

// /* 🎢 Slide Down */
// export const slideDown = (el, duration = DEFAULT_DURATION) => {
//   if (!el) return;
//   el.style.removeProperty("display");
//   let display = getComputedStyle(el).display;
//   if (display === "none") display = "block";
//   el.style.display = display;

//   const height = el.scrollHeight + "px";
//   el.style.overflow = "hidden";
//   el.style.height = 0;
//   el.offsetHeight; // force repaint
//   el.style.transition = `height ${duration}ms ${DEFAULT_EASING}`;
//   el.style.height = height;

//   setTimeout(() => {
//     el.style.height = "";
//     el.style.overflow = "";
//     el.style.transition = "";
//   }, duration);
// };

// /* 🎢 Slide Up */
// export const slideUp = (el, duration = DEFAULT_DURATION) => {
//   if (!el) return;
//   el.style.height = el.scrollHeight + "px";
//   el.style.overflow = "hidden";
//   el.offsetHeight; // force repaint
//   el.style.transition = `height ${duration}ms ${DEFAULT_EASING}`;
//   el.style.height = 0;

//   setTimeout(() => {
//     el.style.display = "none";
//     el.style.height = "";
//     el.style.overflow = "";
//     el.style.transition = "";
//   }, duration);
// };

// /* 🔄 Slide Toggle */
// export const slideToggle = (el, duration = DEFAULT_DURATION) => {
//   if (!el) return;
//   if (getComputedStyle(el).display === "none") {
//     slideDown(el, duration);
//   } else {
//     slideUp(el, duration);
//   }
// };

// /* ⬆️⬇️ Expand/Collapse (height auto) */
// export const expand = (el, duration = DEFAULT_DURATION) => {
//   slideDown(el, duration);
// };

// export const collapse = (el, duration = DEFAULT_DURATION) => {
//   slideUp(el, duration);
// };


