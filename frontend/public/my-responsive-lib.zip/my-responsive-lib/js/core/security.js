/* security.js
   Frontend security helpers: sanitization, escaping, validation
*/

/**
 * Escape HTML entities to prevent XSS
 * @param {string} str
 * @returns {string}
 */
export function escapeHTML(str) {
    return str.replace(/[&<>"'`=\/]/g, (char) => {
      const map = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;",
        "`": "&#x60;",
        "=": "&#x3D;",
        "/": "&#x2F;",
      };
      return map[char];
    });
  }
  
  /**
   * Strip all HTML tags (keep text only)
   * @param {string} str
   * @returns {string}
   */
  export function stripHTML(str) {
    const div = document.createElement("div");
    div.innerHTML = str;
    return div.textContent || div.innerText || "";
  }
  
  /**
   * Basic input sanitization (escape + trim)
   * @param {string} str
   * @returns {string}
   */
  export function sanitizeInput(str) {
    return escapeHTML(str.trim());
  }
  
  /**
   * Validate safe URL (only http/https)
   * @param {string} url
   * @returns {boolean}
   */
  export function isSafeURL(url) {
    try {
      const parsed = new URL(url, window.location.origin);
      return ["http:", "https:"].includes(parsed.protocol);
    } catch {
      return false;
    }
  }
  
  /**
   * Validate email format
   * @param {string} email
   * @returns {boolean}
   */
  export function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }
  
  /**
   * Generate random secure token
   * @param {number} length
   * @returns {string}
   */
  export function generateToken(length = 32) {
    const chars =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
    const array = new Uint32Array(length);
    crypto.getRandomValues(array);
    return Array.from(array, (num) => chars[num % chars.length]).join("");
  }
  
  /**
   * Hash string with SHA-256
   * @param {string} str
   * @returns {Promise<string>}
   */
  export async function hashSHA256(str) {
    const encoder = new TextEncoder();
    const data = encoder.encode(str);
    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    return Array.from(new Uint8Array(hashBuffer))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  }
  
  
  
  