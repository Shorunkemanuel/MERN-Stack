/* =======================================
   String Helpers
   ======================================= */

export function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

export function kebabCase(str) {
  return str.replace(/\s+/g, "-").toLowerCase();
}

export function truncate(str, length = 50) {
  return str.length > length ? str.slice(0, length) + "..." : str;
}