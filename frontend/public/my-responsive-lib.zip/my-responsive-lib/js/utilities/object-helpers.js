/* =======================================
   Object Helpers
   ======================================= */

export function deepClone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

export function mergeObjects(target, source) {
  return { ...target, ...source };
}

export function isEmpty(obj) {
  return Object.keys(obj).length === 0;
}