/* =======================================
   Device Helpers
   ======================================= */

export function isMobile() {
  return /Mobi|Android/i.test(navigator.userAgent);
}

export function isTablet() {
  return /Tablet|iPad/i.test(navigator.userAgent);
}

export function isDesktop() {
  return !isMobile() && !isTablet();
}