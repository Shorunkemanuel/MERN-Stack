/**
 * Grid.js
 * Dynamic grid utilities to complement CSS Grid system
 */

const Grid = (() => {
    /**
     * Equalize heights of all columns inside a row/grid
     * @param {string} selector - CSS selector for grid row
     */
    const equalizeHeights = (selector) => {
      const rows = document.querySelectorAll(selector);
      rows.forEach((row) => {
        let maxHeight = 0;
        const children = row.children;
  
        // Reset first
        Array.from(children).forEach((col) => {
          col.style.height = "auto";
        });
  
        // Find max height
        Array.from(children).forEach((col) => {
          if (col.offsetHeight > maxHeight) {
            maxHeight = col.offsetHeight;
          }
        });
  
        // Apply max height
        Array.from(children).forEach((col) => {
          col.style.height = `${maxHeight}px`;
        });
      });
    };
  
    /**
     * Enable Masonry-like auto placement using CSS Grid
     * @param {string} selector - Grid container selector
     * @param {number} rowHeight - Base row height
     */
    const masonryGrid = (selector, rowHeight = 10) => {
      const grid = document.querySelector(selector);
      if (!grid) return;
  
      const items = grid.children;
      Array.from(items).forEach((item) => {
        const rowSpan = Math.ceil(
          (item.getBoundingClientRect().height + rowHeight) / rowHeight
        );
        item.style.gridRowEnd = `span ${rowSpan}`;
      });
    };
  
    /**
     * Toggle between grid layouts dynamically
     * @param {string} selector - Grid container
     * @param {string} layoutClass - Class to toggle (e.g., 'grid-cols-2')
     */
    const toggleLayout = (selector, layoutClass) => {
      const grid = document.querySelector(selector);
      if (grid) {
        grid.classList.toggle(layoutClass);
      }
    };
  
    return {
      equalizeHeights,
      masonryGrid,
      toggleLayout,
    };
  })();
  
  // Example Usage
  // Grid.equalizeHeights(".row");
  // Grid.masonryGrid(".grid", 8);
  // Grid.toggleLayout(".grid", "grid-cols-2");
  
  export default Grid;
  
  
  



// /**
//  * grid.js
//  * Advanced Grid Layout Manager
//  * ============================
//  * - Create responsive CSS Grid containers
//  * - Support for named grid areas
//  * - Dynamic row/column updates
//  * - Works alongside flex-based grid system
//  */

// export const Grid = (() => {
//   /**
//    * Initialize a grid container
//    * @param {HTMLElement} element - Grid container
//    * @param {Object} options - Grid config
//    */
//   function create(element, options = {}) {
//     if (!element) return;

//     const {
//       columns = "1fr",
//       rows = "auto",
//       gap = "1rem",
//       areas = null,
//       responsive = {}
//     } = options;

//     element.style.display = "grid";
//     element.style.gridTemplateColumns = columns;
//     element.style.gridTemplateRows = rows;
//     element.style.gap = gap;

//     if (areas) {
//       element.style.gridTemplateAreas = areas.map(r => `"${r}"`).join(" ");
//     }

//     // Apply responsive breakpoints
//     applyResponsive(element, responsive);
//   }

//   /**
//    * Update grid structure dynamically
//    */
//   function update(element, newOptions = {}) {
//     if (!element) return;
//     create(element, newOptions); // just re-run with new options
//   }

//   /**
//    * Apply responsive CSS via injected stylesheet
//    */
//   function applyResponsive(element, responsive) {
//     if (!responsive || Object.keys(responsive).length === 0) return;

//     const className = `grid-${Date.now()}`;
//     element.classList.add(className);

//     let css = "";

//     for (const bp in responsive) {
//       const { columns, rows, areas, gap } = responsive[bp];
//       css += `
//         @media (min-width: var(--breakpoint-${bp})) {
//           .${className} {
//             ${columns ? `grid-template-columns: ${columns};` : ""}
//             ${rows ? `grid-template-rows: ${rows};` : ""}
//             ${gap ? `gap: ${gap};` : ""}
//             ${
//               areas
//                 ? `grid-template-areas: ${areas.map(r => `"${r}"`).join(" ")};`
//                 : ""
//             }
//           }
//         }
//       `;
//     }

//     injectStyles(css);
//   }

//   /**
//    * Assign a grid area to an element
//    */
//   function assignArea(element, areaName) {
//     if (!element) return;
//     element.style.gridArea = areaName;
//   }

//   /**
//    * Inject CSS into the document <head>
//    */
//   function injectStyles(css) {
//     let styleTag = document.getElementById("grid-styles");
//     if (!styleTag) {
//       styleTag = document.createElement("style");
//       styleTag.id = "grid-styles";
//       document.head.appendChild(styleTag);
//     }
//     styleTag.textContent += css;
//   }

//   return { create, update, assignArea };
// })();




// /**
//  * Grid.js
//  * Dynamic CSS Grid helpers for layout manipulation
//  */

// const Grid = (() => {
//   /**
//    * Apply a CSS grid layout dynamically
//    * @param {string} selector - Target container
//    * @param {object} options - Grid config (columns, rows, gap, responsive)
//    */
//   const setGrid = (selector, options = {}) => {
//     const el = document.querySelector(selector);
//     if (!el) return;

//     if (options.columns) el.style.gridTemplateColumns = options.columns;
//     if (options.rows) el.style.gridTemplateRows = options.rows;
//     if (options.gap) el.style.gap = typeof options.gap === "number" ? `${options.gap}px` : options.gap;
//     if (options.align) el.style.alignItems = options.align;
//     if (options.justify) el.style.justifyItems = options.justify;
//   };

//   /**
//    * Responsive grid columns
//    * @param {string} selector - Target container
//    * @param {object} breakpoints - { sm, md, lg, xl, xxl }
//    */
//   const responsiveGrid = (selector, breakpoints = {}) => {
//     const el = document.querySelector(selector);
//     if (!el) return;

//     const updateGrid = () => {
//       const width = window.innerWidth;

//       if (width >= 1400 && breakpoints.xxl) {
//         el.style.gridTemplateColumns = breakpoints.xxl;
//       } else if (width >= 1200 && breakpoints.xl) {
//         el.style.gridTemplateColumns = breakpoints.xl;
//       } else if (width >= 992 && breakpoints.lg) {
//         el.style.gridTemplateColumns = breakpoints.lg;
//       } else if (width >= 768 && breakpoints.md) {
//         el.style.gridTemplateColumns = breakpoints.md;
//       } else if (width >= 576 && breakpoints.sm) {
//         el.style.gridTemplateColumns = breakpoints.sm;
//       } else if (breakpoints.default) {
//         el.style.gridTemplateColumns = breakpoints.default;
//       }
//     };

//     updateGrid();
//     window.addEventListener("resize", updateGrid);
//   };

//   /**
//    * Add item placement to a grid child
//    * @param {string} selector - Child element
//    * @param {object} position - { colStart, colEnd, rowStart, rowEnd }
//    */
//   const placeItem = (selector, position = {}) => {
//     const el = document.querySelector(selector);
//     if (!el) return;

//     if (position.colStart) el.style.gridColumnStart = position.colStart;
//     if (position.colEnd) el.style.gridColumnEnd = position.colEnd;
//     if (position.rowStart) el.style.gridRowStart = position.rowStart;
//     if (position.rowEnd) el.style.gridRowEnd = position.rowEnd;
//   };

//   /**
//    * Reset grid to default
//    * @param {string} selector - Grid container
//    */
//   const resetGrid = (selector) => {
//     const el = document.querySelector(selector);
//     if (!el) return;

//     el.style.gridTemplateColumns = "";
//     el.style.gridTemplateRows = "";
//     el.style.gap = "";
//     el.style.alignItems = "";
//     el.style.justifyItems = "";
//   };

//   return {
//     setGrid,
//     responsiveGrid,
//     placeItem,
//     resetGrid,
//   };
// })();

// // Example usage:
// // Grid.setGrid(".grid", { columns: "repeat(3, 1fr)", gap: "16px" });
// // Grid.responsiveGrid(".grid", { sm: "1fr", md: "repeat(2, 1fr)", lg: "repeat(4, 1fr)" });
// // Grid.placeItem(".item1", { colStart: 1, colEnd: 3, rowStart: 1, rowEnd: 2 });
// // Grid.resetGrid(".grid");

// export default Grid;

