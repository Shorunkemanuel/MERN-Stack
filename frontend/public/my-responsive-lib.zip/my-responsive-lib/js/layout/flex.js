/**
 * Flex.js
 * Dynamic Flexbox utilities to complement CSS flex system
 */

const Flex = (() => {
    /**
     * Toggle flex direction between row and column
     * @param {string} selector - Container selector
     */
    const toggleDirection = (selector) => {
      const el = document.querySelector(selector);
      if (!el) return;
      el.style.flexDirection =
        el.style.flexDirection === "row" ? "column" : "row";
    };
  
    /**
     * Justify content dynamically
     * @param {string} selector - Container selector
     * @param {string} value - flex-start | center | flex-end | space-between | space-around | space-evenly
     */
    const justifyContent = (selector, value) => {
      const el = document.querySelector(selector);
      if (el) el.style.justifyContent = value;
    };
  
    /**
     * Align items dynamically
     * @param {string} selector - Container selector
     * @param {string} value - stretch | flex-start | center | flex-end | baseline
     */
    const alignItems = (selector, value) => {
      const el = document.querySelector(selector);
      if (el) el.style.alignItems = value;
    };
  
    /**
     * Wrap items toggle
     * @param {string} selector - Container selector
     */
    const toggleWrap = (selector) => {
      const el = document.querySelector(selector);
      if (!el) return;
      el.style.flexWrap =
        el.style.flexWrap === "wrap" ? "nowrap" : "wrap";
    };
  
    /**
     * Order elements dynamically
     * @param {string} selector - Element selector
     * @param {number} order - Order index
     */
    const setOrder = (selector, order) => {
      const els = document.querySelectorAll(selector);
      els.forEach((el) => {
        el.style.order = order;
      });
    };
  
    /**
     * Grow or shrink flex items
     * @param {string} selector - Element selector
     * @param {number} grow - flex-grow value
     * @param {number} shrink - flex-shrink value
     * @param {string} basis - flex-basis (e.g., "auto", "50%", "200px")
     */
    const setFlex = (selector, grow = 1, shrink = 1, basis = "auto") => {
      const els = document.querySelectorAll(selector);
      els.forEach((el) => {
        el.style.flex = `${grow} ${shrink} ${basis}`;
      });
    };
  
    return {
      toggleDirection,
      justifyContent,
      alignItems,
      toggleWrap,
      setOrder,
      setFlex,
    };
  })();
  
  // Example Usage
  // Flex.toggleDirection(".flex-container");
  // Flex.justifyContent(".flex-container", "center");
  // Flex.alignItems(".flex-container", "flex-start");
  // Flex.toggleWrap(".flex-container");
  // Flex.setOrder(".flex-item-1", 2);
  // Flex.setFlex(".flex-item", 1, 0, "50%");
  
  export default Flex;
  
  
  
  