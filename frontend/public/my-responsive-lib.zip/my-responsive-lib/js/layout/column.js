/**
 * Containers.js
 * Manage responsive containers dynamically
 */

const Containers = (() => {
    /**
     * Apply container type (fixed or fluid)
     * @param {string} selector - Target element
     * @param {string} type - "fixed" | "fluid"
     */
    const setContainer = (selector, type = "fixed") => {
      const el = document.querySelector(selector);
      if (!el) return;
  
      if (type === "fluid") {
        el.classList.remove("container");
        el.classList.add("container-fluid");
      } else {
        el.classList.remove("container-fluid");
        el.classList.add("container");
      }
    };
  
    /**
     * Add responsive max-widths to container
     * @param {string} selector - Target container
     * @param {object} breakpoints - { sm, md, lg, xl, xxl }
     */
    const setResponsiveWidths = (selector, breakpoints = {}) => {
      const el = document.querySelector(selector);
      if (!el) return;
  
      const updateWidth = () => {
        const width = window.innerWidth;
  
        if (width >= 1400 && breakpoints.xxl) {
          el.style.maxWidth = breakpoints.xxl;
        } else if (width >= 1200 && breakpoints.xl) {
          el.style.maxWidth = breakpoints.xl;
        } else if (width >= 992 && breakpoints.lg) {
          el.style.maxWidth = breakpoints.lg;
        } else if (width >= 768 && breakpoints.md) {
          el.style.maxWidth = breakpoints.md;
        } else if (width >= 576 && breakpoints.sm) {
          el.style.maxWidth = breakpoints.sm;
        } else {
          el.style.maxWidth = "100%"; // fallback
        }
      };
  
      updateWidth();
      window.addEventListener("resize", updateWidth);
    };
  
    /**
     * Center container horizontally
     * @param {string} selector - Target container
     */
    const centerContainer = (selector) => {
      const el = document.querySelector(selector);
      if (!el) return;
  
      el.style.marginLeft = "auto";
      el.style.marginRight = "auto";
    };
  
    /**
     * Reset container to default state
     * @param {string} selector - Target container
     */
    const resetContainer = (selector) => {
      const el = document.querySelector(selector);
      if (!el) return;
  
      el.classList.remove("container", "container-fluid");
      el.style.maxWidth = "";
      el.style.marginLeft = "";
      el.style.marginRight = "";
    };
  
    return {
      setContainer,
      setResponsiveWidths,
      centerContainer,
      resetContainer,
    };
  })();
  
  // Example usage:
  // Containers.setContainer(".my-container", "fluid");
  // Containers.setResponsiveWidths(".my-container", { sm: "540px", md: "720px", lg: "960px", xl: "1140px", xxl: "1320px" });
  // Containers.centerContainer(".my-container");
  // Containers.resetContainer(".my-container");
  
  export default Containers;
  
  
  