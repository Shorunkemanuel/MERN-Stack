spacing.js


/**
 * Spacing.js
 * Dynamic margin & padding helpers
 */

const Spacing = (() => {
  /**
   * Apply spacing (margin/padding) dynamically
   * @param {string} selector - Target element selector
   * @param {string} property - "margin" or "padding"
   * @param {string} side - "top" | "bottom" | "left" | "right" | "x" | "y" | ""
   * @param {string|number} value - CSS size (e.g., "16px", "1rem", 20)
   */
  const setSpacing = (selector, property, side = "", value = 0) => {
    const el = document.querySelector(selector);
    if (!el) return;

    let cssProp = property;
    if (side === "x") {
      el.style[`${property}Left`] = typeof value === "number" ? `${value}px` : value;
      el.style[`${property}Right`] = typeof value === "number" ? `${value}px` : value;
      return;
    }
    if (side === "y") {
      el.style[`${property}Top`] = typeof value === "number" ? `${value}px` : value;
      el.style[`${property}Bottom`] = typeof value === "number" ? `${value}px` : value;
      return;
    }
    if (side) cssProp += side.charAt(0).toUpperCase() + side.slice(1);

    el.style[cssProp] = typeof value === "number" ? `${value}px` : value;
  };

  /**
   * Reset spacing to default
   * @param {string} selector - Target element selector
   */
  const resetSpacing = (selector) => {
    const el = document.querySelector(selector);
    if (!el) return;
    el.style.margin = "";
    el.style.padding = "";
  };

  /**
   * Add responsive spacing (applies at certain breakpoints)
   * @param {string} selector - Target element selector
   * @param {string} property - "margin" or "padding"
   * @param {string} side - "top" | "bottom" | "left" | "right" | "x" | "y" | ""
   * @param {object} values - Breakpoint values { sm: "8px", md: "16px", lg: "24px" }
   */
  const responsiveSpacing = (selector, property, side, values = {}) => {
    const el = document.querySelector(selector);
    if (!el) return;

    const updateSpacing = () => {
      const width = window.innerWidth;

      if (width >= 1200 && values.xl) {
        setSpacing(selector, property, side, values.xl);
      } else if (width >= 992 && values.lg) {
        setSpacing(selector, property, side, values.lg);
      } else if (width >= 768 && values.md) {
        setSpacing(selector, property, side, values.md);
      } else if (width >= 576 && values.sm) {
        setSpacing(selector, property, side, values.sm);
      } else if (values.default) {
        setSpacing(selector, property, side, values.default);
      }
    };

    // Initial load + resize
    updateSpacing();
    window.addEventListener("resize", updateSpacing);
  };

  return {
    setSpacing,
    resetSpacing,
    responsiveSpacing,
  };
})();

// Example usage:
// Spacing.setSpacing(".box", "margin", "top", "20px");
// Spacing.setSpacing(".box", "padding", "x", 16);
// Spacing.responsiveSpacing(".box", "margin", "y", { sm: "8px", md: "16px", lg: "32px", xl: "48px" });
// Spacing.resetSpacing(".box");

export default Spacing;

